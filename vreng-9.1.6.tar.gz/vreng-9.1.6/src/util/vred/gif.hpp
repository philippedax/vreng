#ifndef GIF_H
#define GIF_H

extern unsigned char *load_gif(unsigned char*,int, unsigned char rgbpalette[3*256], int& largeur, int& hauteur,int Verbose);

#endif
