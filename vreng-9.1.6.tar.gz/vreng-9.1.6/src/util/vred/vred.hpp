#ifndef VRED_HPP
#define VRED_HPP

#include <iostream>
#include "sysdep.hpp"	// system includes
#include "main.hpp"	// class Vred

using namespace std;

#endif
