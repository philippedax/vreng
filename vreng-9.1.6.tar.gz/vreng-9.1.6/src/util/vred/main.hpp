#ifndef MAIN_HPP
#define MAIN_HPP

class Group;

class Vred {

public:
  static Group *treeRoot;

};

#endif
