#ifndef INPUT_H
#define INPUT_H

#include "vre.hpp"

extern int FileToGroup(FILE *fp, Group *grp);

#endif
