/****************************************************************************
 *                             VREL COMPONENTS                              *
 *                                                                          *
 *                           Copyright (C) 2000                             *
 *     Yanneck Chevalier, Pascal Belin, Alexis Jeannerod, Julien Dauphin    *
 *                                                                          *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by   *
 *   the Free Software Foundation; either version 2 of the License, or      *
 *   (at your option) any later version.                                    *
 *                                                                          *
 *   This program is distributed in the hope that it will be useful,        *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *   GNU General Public License for more details.                           *
 ****************************************************************************/

#ifndef ENVVAR_HPP
#define ENVVAR_HPP

#include "data.hpp"

/**
 * class Env_var
 */
class Env_var
{
 public:

  char nom[256][30];  ///< Tableau des noms de variables.
  Data** donnee;      ///< Tableau des data associees.
  int count;          ///< (count-1) = nombre de variables declarees.

  Env_var(); ///< initialisation des tableaux et du compteur.

  int parcours(const char * str);
  // Parcours la liste chainee des variables existantes et renvoie l'index
  // sur cette variable si la variable existe deja. Sinon, renvoie 0.

  void declaration(const char* str);
  // Ajouter une variable dans le tableau de nom.

  void declaration(const char * str, float val);
  // Ajouter une variable dans le tableau de nom et l'affecter a un nombre.
  
  void declaration(const char * var, const char *str);
  // Ajouter une variable dans le tableau de nom et l'affecter a une chaine.

  int affectation(const char *, Data*);
  // Mathode d'affectation; la data sera d'abord avaluae (mathode get_data).

  int affectation2(const char *, Data*);
  // Mathode d'affectation sans evaluation (ie la data peut etre un pointeur 
  // sur un objet de type Variable).
  
  Data* eval(const char *);
  // Fonction qui renvoie la valeur d'une variable.

  virtual ~Env_var();		///< Destructeur

};

#endif
