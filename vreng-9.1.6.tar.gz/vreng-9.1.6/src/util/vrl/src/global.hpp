#ifndef GLOBAL_H
#define GLOBAL_H

#include "sysdep.h"	// system includes
#include <iostream>

using namespace std;

#endif  // GLOBAL_H
