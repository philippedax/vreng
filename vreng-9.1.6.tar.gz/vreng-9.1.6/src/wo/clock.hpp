//---------------------------------------------------------------------------
// VREng (Virtual Reality Engine)	http://vreng.enst.fr/
//
// Copyright (C) 1997-2009 Philippe Dax
// Telecom-ParisTech (Ecole Nationale Superieure des Telecommunications)
//
// VREng is a free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public Licence as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// VREng is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//---------------------------------------------------------------------------
#ifndef CLOCK_HPP
#define CLOCK_HPP

#include "wobject.hpp"

#define CLOCK_TYPE	27
#define	CLOCK_NAME	"Clock"


/**
 * Clock class
 */
class Clock: public WObject {

private:
  enum {
    SECOND,
    MINUTE,
    HOUR
  }; // needles

  uint8_t needle;	///< which needle: s | m | h
  uint8_t sec;		///< secondes
  uint8_t min;		///< minutes
  uint8_t hour;		///< hour
  uint16_t yday;	///< day number in year
  uint8_t sec_last;	///< last sec
  uint8_t min_last;	///< last min
  uint8_t hour_last;	///< last hour
  float daytime;	///< midday time
  float risetime;	///< rise time
  float falltime;	///< fall time
  bool haveneedle;	///< flag

public:
  static const OClass oclass;	///< class variable

  virtual const OClass* getOClass() {return &oclass;}

  Clock(char *l);	///< Constructor
  Clock();		///< Constructor internal

  static void funcs();	///< init funclist

  static WObject * (creator)(char *l);

  virtual void changePermanent(float lasting);

  virtual void updateTime(time_t s, time_t u, float *lasting);

  virtual void quit();

private:
  void init();		///< init time

  virtual void parser(char *l);
  /**< Parses */

};

#endif
