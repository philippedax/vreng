//---------------------------------------------------------------------------
// VREng (Virtual Reality Engine)	http://vreng.enst.fr/
//
// Copyright (C) 1997-2009 Philippe Dax
// Telecom-ParisTech (Ecole Nationale Superieure des Telecommunications)
//
// VREng is a free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public Licence as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// VREng is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//---------------------------------------------------------------------------
#include "vreng.hpp"
#include "template.hpp"
#include "move.hpp"     // gotoFront


const OClass Template::oclass(TEMPLATE_TYPE, "Template", Template::creator);


/* Creation from a file */
WObject * Template::creator(char *l)
{
  return new Template(l);
}

void Template::defaults()
{
}

/* Parser */
void Template::parser(char *l)
{
  defaults();
  l = tokenize(l);
  begin_while_parse(l) {
    l = parse()->parseAttributes(l, this);
    if (!l) break;
  }
  end_while_parse(l);
}

/* Behavior */
void Template::behavior()
{
  enableBehavior(NO_ELEMENTARY_MOVE);
  enableBehavior(COLLIDE_NEVER);
  enableBehavior(SPECIFIC_RENDER);
  setRenderPrior(PRIOR_MEDIUM);

  initMobileObject(0);
  updatePosition();
}

/* Specific inits */
void Template::inits()
{
}

/* Constructor */
Template::Template(char *l)
{
  parser(l);
  behavior();
  inits();
}

void Template::buildScreen()
{
  V3 dim;
  getDim(dim);
}

/* Computes something at each loop */
void Template::changePermanent(float lasting)
{
}

/* Renders at each loop */
void Template::render()
{
  updatePosition();

  // push
  glPushAttrib(GL_ALL_ATTRIB_BITS);
  glPushMatrix();
  glEnable(GL_LIGHTING);
  glEnable(GL_CULL_FACE);

  // render

  // pop
  glDisable(GL_CULL_FACE);
  glDisable(GL_TEXTURE_2D);
  glDisable(GL_LIGHTING);
  glPopMatrix();
  glPopAttrib();
}

void Template::quit()
{
}

void Template::action1(Template *template, void *d, time_t s, time_t u)
{
}

void Template::action2(Template *template, void *d, time_t s, time_t u)
{
}

void TemplatTemplate::funcs()
{
  setActionFunc(TEMPLATE_TYPE, 0, WO_ACTION action1, "action1");
  setActionFunc(TEMPLATE_TYPE, 1, WO_ACTION action2, "action2");
  setActionFunc(TEMPLATE_TYPE, 2, WO_ACTION gotoFront, "Approach---
}
